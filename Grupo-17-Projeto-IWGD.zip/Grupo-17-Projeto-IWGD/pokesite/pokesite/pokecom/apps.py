from django.apps import AppConfig


class PokecomConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pokecom'
